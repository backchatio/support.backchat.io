<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

/* For SSO */
define( 'FRONT_END_COOKIE_SSO_SECRET', '21f98a3bcddc65267ff8564f258e7cc56352f082a660c4e158f853f621d151b939129210aee1b4a11b5a62b1976fbeca060b0abfc73ed2a82b26aeb7f85b30aa' );

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true); //Added by WP-Cache Manager
define('DB_NAME', 'wp_support_backchat_io');

/** MySQL database username */
define('DB_USER', 'wp_support');

/** MySQL database password */
define('DB_PASSWORD', 'G5xmmKfHfPTX23');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ']-}&Y8R~*d=UNU[F%K;.Fl r+cI-nr#4v+D0 w|F%en9i1;v=_)To[$MI_jElx~9');
define('SECURE_AUTH_KEY',  'R+9*U=zCL?:+AKrD8gJ-n_0PqX!2i;K.=7G0+-3I(tUoV`6f{A4[PI}ShkLiY(A9');
define('LOGGED_IN_KEY',    'P*0BZGgBZ]I*R]ao9h2-;CU3&`<V+:TW1A@exn,e{i(Qt}f2=[wl2=M+#$#auA7G');
define('NONCE_KEY',        '2-]s?uV4xU/*UG!SsH6|Rm h=PWO=P& P.l{kcM&K#|-n!Z}$CNt]c8?,|]&^_@}');
define('AUTH_SALT',        'HaG>R{fghnv?@=w.wz786$2IscQ}[^-;F6Z+ 9k}>0pTnea%L_XY/8UI):!] JXw');
define('SECURE_AUTH_SALT', 'iI|+>$&] ?7rh-ncCl*=,:~:eB{c-!y*GqPF+@T 8f;sjYBbS?`OL=GK|5Avn`v5');
define('LOGGED_IN_SALT',   '](o+1Hy-X4-L4z2sVezdG)P(9%[+:rz6mLhlXcl-}{H<l%)-CrREsIu0wA%tq*+#');
define('NONCE_SALT',       'ok5-#~4`%%m-}c|([}j~ua,Q0~yn)`^|Sr[#-QZ=}]bP%>eq(%K/GU1=]){0.DlS');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
